# RoutePartage — prototype mobile

## Tester sur téléphone
1. Ouvre `index.html` dans un navigateur récent pour tester la version locale.
2. Pour l'ouvrir plus facilement sur ton téléphone, héberge le fichier gratuitement sur un service statique (par exemple GitHub Pages, Netlify ou Cloudflare Pages), puis ouvre l'adresse générée sur ton téléphone.
3. Le prototype conserve les annonces et réservations dans le stockage local du navigateur. Les données ne sont pas partagées avec d'autres appareils.

## Fonctions incluses
- Recherche de trajets par départ, destination et date
- Annonces de démonstration
- Publication d'un trajet
- Réservation locale de démonstration
- Navigation mobile

## Avant un lancement réel
Il faudra notamment ajouter un backend et une base de données, des comptes sécurisés, une messagerie, la modération/signalement, la gestion des annulations, une solution de paiement si nécessaire, les documents juridiques et la conformité RGPD. Vérifie aussi le cadre légal du covoiturage et le partage des frais.

Ce projet est une maquette fonctionnelle, pas une application prête à gérer de vrais passagers ou paiements.
